# -*- coding: utf-8 -*-
# Copyright (c) 2018, Frappe Technologies Pvt. Ltd. and Contributors
# See license.txt
from __future__ import unicode_literals

import frappe
import unittest
from erpnext.hr.doctype.employee.test_employee import make_employee
from frappe.utils import now_datetime
from datetime import timedelta

class TestHRSettings(unittest.TestCase):
	pass

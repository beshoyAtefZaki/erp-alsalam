frappe.ui.form.on("Leave Type", {
	refresh: function(frm) {
	}
});

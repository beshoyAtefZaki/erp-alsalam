from __future__ import unicode_literals

def get_data():
	return {
		'fieldname': 'leave_type',
		'transactions': [
			{
				'items': ['Leave Allocation', 'Leave Application'],
			},
			{
				'items': ['Attendance', 'Leave Encashment']
			}
		]
	}
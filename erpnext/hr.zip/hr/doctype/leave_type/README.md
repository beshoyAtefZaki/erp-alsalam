Type of Leave.

e.g.

- Casual Leave
- Sick Leave
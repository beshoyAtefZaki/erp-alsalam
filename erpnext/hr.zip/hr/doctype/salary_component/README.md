Type of earning and deductions that is a part of the salary.

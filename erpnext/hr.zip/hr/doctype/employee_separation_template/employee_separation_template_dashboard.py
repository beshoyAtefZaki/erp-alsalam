from __future__ import unicode_literals
from frappe import _

def get_data():
     return {
        'fieldname': 'employee_separation_template',
        'transactions': [
            {
                'items': ['Employee Separation']
            },
        ],
    }
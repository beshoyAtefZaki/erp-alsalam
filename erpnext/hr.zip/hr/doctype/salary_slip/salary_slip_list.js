frappe.listview_settings['Salary Slip'] = {
	add_fields: ["employee", "employee_name"],
};
